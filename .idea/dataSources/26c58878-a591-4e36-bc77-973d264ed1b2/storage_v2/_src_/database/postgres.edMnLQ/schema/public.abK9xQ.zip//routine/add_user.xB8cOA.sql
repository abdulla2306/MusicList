create procedure add_user(IN user_name text, IN user_email text)
    language plpgsql
as
$$
BEGIN
    INSERT INTO users (name, email) VALUES (user_name, user_email);
END;
$$;

alter procedure add_user(text, text) owner to postgres;

