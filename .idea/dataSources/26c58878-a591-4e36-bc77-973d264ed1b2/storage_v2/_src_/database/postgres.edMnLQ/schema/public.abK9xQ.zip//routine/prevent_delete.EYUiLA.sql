create function prevent_delete() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE EXCEPTION 'Buyurtmalarni o‘chirib bo‘lmaydi!';
END;
$$;

alter function prevent_delete() owner to postgres;

