create function log_salary_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO salary_log (employee_id, old_salary, new_salary, changed_at)
    VALUES (OLD.id, OLD.salary, NEW.salary, NOW());
    RETURN NEW;
END;
$$;

alter function log_salary_changes() owner to postgres;

