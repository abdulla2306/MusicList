create view pg_wait_events(type, name, description) as
SELECT type,
       name,
       description
FROM pg_get_wait_events() pg_get_wait_events(type, name, description);

alter table pg_wait_events
    owner to postgres;

grant select on pg_wait_events to public;

